#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "clz_mini.h"

#include "clz_rice.c"
#include "clz_decrice.c"

#include "clz_encode.c"
#include "clz_decode.c"

